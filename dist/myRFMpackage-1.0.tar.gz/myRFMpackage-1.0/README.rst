myRFMpackage
---------

"myRFMpackage" provides basic funtionality for working with customer data.