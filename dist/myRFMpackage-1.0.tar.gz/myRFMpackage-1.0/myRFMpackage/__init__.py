#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb  6 11:17:03 2019

@author: katsiuba
"""

from .calculateRFM import calculateRFM